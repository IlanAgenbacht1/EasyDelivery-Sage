package com.clone.granite.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.clone.granite.Model.ItemParcel;

public class DeliveryDb {


    private static final String DATABASE_NAME = "DeliveryDb";
    private static final String DOCUMENT_TABLE = "DocumentTable";
    private static final String PARCEL_TABLE = "ParcelTable";
    private final int DATABASE_VERSION = 1;
    private Context ourContext;


    private SQLiteDatabase ourDatabase;
    private DBHelper ourHelper;


    public static final String KEY_ROWID = "_id";
    public static final String KEY_DOCUMENT = "_docu";
    public static final String KEY_SIGN = "_sign";
    public static final String KEY_PIC = "_pic";
    public static final String KEY_UNIT = "_unit";



    public static final String KEY_ROWID2 = "_id2";
    public static final String KEY_DOCUMENT2 = "_docu2";
    public static final String KEY_PARCEL = "_parcel";


    public DeliveryDb(Context ourContext) {
        this.ourContext = ourContext;
    }


    private class DBHelper extends SQLiteOpenHelper {


        public DBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {



            String sqlCreateDocuTable = "CREATE TABLE " + DOCUMENT_TABLE + " (" +
                    KEY_ROWID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    KEY_DOCUMENT + " TEXT NOT NULL, " +
                    KEY_SIGN + " TEXT NOT NULL, " +
                    KEY_PIC + " TEXT NOT NULL, " +
                    KEY_UNIT + " TEXT NOT NULL);";

            db.execSQL(sqlCreateDocuTable);


            String sqlCreateParcelTable = "CREATE TABLE " + PARCEL_TABLE + " (" +
                    KEY_ROWID2 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    KEY_DOCUMENT2 + " TEXT NOT NULL, " +
                    KEY_PARCEL + " TEXT NOT NULL);";

            db.execSQL(sqlCreateParcelTable);


        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            db.execSQL("DROP TABLE IF EXISTS " + DOCUMENT_TABLE);
            db.execSQL("DROP TABLE IF EXISTS " + PARCEL_TABLE);


            onCreate(db);

        }


    }

    public DeliveryDb open() throws SQLException {

        ourHelper = new DBHelper(ourContext);

        ourDatabase = ourHelper.getWritableDatabase();
        return this;
    }


    public void close() {

        ourHelper.close();
    }



    public long createDocuEntry(ItemParcel item) {


        ContentValues cv = new ContentValues();

        cv.put(KEY_DOCUMENT, item.getDocu());
        cv.put(KEY_SIGN, item.getSign());
        cv.put(KEY_PIC, item.getPic());
        cv.put(KEY_UNIT, item.getUnit());

        return ourDatabase.insert(DOCUMENT_TABLE, null, cv);


    }

    public long createParcelEntry(ItemParcel item) {


        ContentValues cv = new ContentValues();

        cv.put(KEY_DOCUMENT2, item.getDocu());
        cv.put(KEY_PARCEL, item.getSign());

        return ourDatabase.insert(PARCEL_TABLE, null, cv);


    }



    public String getDataDocu() {

        String[] columns = new String[]{KEY_ROWID,KEY_DOCUMENT, KEY_SIGN, KEY_PIC, KEY_UNIT};

        Cursor cs = ourDatabase.query(DOCUMENT_TABLE, columns, null, null, null, null, null);

        String result = "";

        int rowID = cs.getColumnIndex(KEY_ROWID);

        int docuID = cs.getColumnIndex(KEY_DOCUMENT);

        int signID = cs.getColumnIndex(KEY_SIGN);

        int picID = cs.getColumnIndex(KEY_PIC);

        int unitID = cs.getColumnIndex(KEY_UNIT);

        if (cs != null && cs.moveToFirst()) {


            result = result + cs.getString(rowID) + ": " + cs.getString(docuID) + " "
                    + cs.getString(signID) + "," + cs.getString(picID) + "," + cs.getString(unitID) + "\n";
        }

        //cs.close();
        return result;

    }










    public String getDataParcel() {

        String[] columns = new String[]{KEY_ROWID2,KEY_DOCUMENT2, KEY_PARCEL};

        Cursor cs = ourDatabase.query(PARCEL_TABLE, columns, null, null, null, null, null);

        String result = "";

        int rowID = cs.getColumnIndex(KEY_ROWID2);

        int docuID = cs.getColumnIndex(KEY_DOCUMENT2);

        int parcelID = cs.getColumnIndex(KEY_PARCEL);


        if (cs != null && cs.moveToFirst()) {


            result = result + cs.getString(rowID) + ": " + cs.getString(docuID) + " "
                    + cs.getString(parcelID) +  "\n";
        }

        //cs.close();
        return result;

    }


}
