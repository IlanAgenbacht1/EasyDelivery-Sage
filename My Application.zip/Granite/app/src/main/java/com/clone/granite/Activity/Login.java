package com.clone.granite.Activity;

import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.clone.granite.R;

public class Login extends AppCompatActivity {

    private EditText etEmail,etUrl;
    private Button btnlogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.et_email);
        etUrl = findViewById(R.id.et_url);
        btnlogin = findViewById(R.id.btn_login);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etEmail.getText().toString().length() > 0){
                    if (etUrl.getText().toString().length()>0){

                        startActivity(new Intent(Login.this,Dash.class));
                        finish();
                    }else {
                        Toast.makeText(Login.this, "Enter your Api url", Toast.LENGTH_SHORT).show();

                    }
                }else {
                    Toast.makeText(Login.this, "Enter your email", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }
}
