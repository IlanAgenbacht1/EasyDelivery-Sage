package com.clone.granite.Model;

public class ItemParcel {


    private boolean isTextEmpty;
    private String number,hint;

    private String docu,pic,sign,unit;

    public boolean isTextEmpty() {
        return isTextEmpty;
    }

    public void setTextEmpty(boolean textEmpty) {
        isTextEmpty = textEmpty;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDocu() {
        return docu;
    }

    public void setDocu(String docu) {
        this.docu = docu;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public ItemParcel(String hint) {
        this.hint = hint;
    }

    public String getHint() {
        return hint;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }

    public ItemParcel() {

    }

    public String getNumber() {

        return number;
    }

    public void setNumber(String number) {

        this.number = number;
    }
}
