package com.clone.granite.Adapter;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.clone.granite.Activity.Dash;
import com.clone.granite.Model.ItemParcel;
import com.clone.granite.R;

import com.google.android.material.textfield.TextInputLayout;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ParcelAdapter extends RecyclerView.Adapter<ParcelAdapter.ViewHolder> {


    private Context context;
    private ArrayList<ItemParcel> listItems;
    boolean isSubmitClick = false;

    public ParcelAdapter(Context context, ArrayList<ItemParcel> listItems) {

        this.context = context;
        this.listItems = listItems;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_parcel, parent, false);


        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {


        ItemParcel data = listItems.get(holder.getAdapterPosition());
        holder.ll_number.setHint(listItems.get(position).getHint());
        holder.etNumber.setImeOptions(0);
        holder.etNumber.setText(listItems.get(position).getNumber());


//        if (holder.etNumber.getText().toString()==null) {
//            if(isSubmitClick){
//                holder.etNumber.setError("please enter a valid input");
//            }
//            data.setTextEmpty(true);
//        } else {
//            data.setTextEmpty(false);
//            //do something else
//        }

    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        private EditText etNumber;
        private TextInputLayout ll_number;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            etNumber = itemView.findViewById(R.id.et_number);
            ll_number=itemView.findViewById(R.id.ll_number);

            etNumber.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    listItems.get(getAdapterPosition()).setNumber(etNumber.getText().toString());
                    ((Dash) context).isEntry();

                }

                @Override
                public void afterTextChanged(Editable editable) {

                }
            });



        }
    }

    public void setSubmitClick(boolean isTrue){
        this.isSubmitClick = isTrue;
    }

}


