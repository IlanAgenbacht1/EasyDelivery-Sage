package com.clone.EasyDelivery.WebService;

public interface mServiceUrl {


    String BaseURL="https://trigger.synatic.com/v1/flows/NWViMTBmOTdiYmRhNzA0OWJiODkyMmI4/Yzc1NDQ5ZGItNjVmNy00Y2ZhLWIzNGQtOWUxOTU3N2YwN2E5?";


}
