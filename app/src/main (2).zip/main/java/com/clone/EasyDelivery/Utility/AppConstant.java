package com.clone.EasyDelivery.Utility;


import android.location.Location;
import android.widget.ArrayAdapter;

import com.clone.EasyDelivery.Model.ItemParcel;

import java.util.ArrayList;
import java.util.List;

public class AppConstant {

    public static String DOCUMENT=" ";
    public static String PARCEL_NO=" ";
    public static String COMPANY = " ";
    public static String SIGN_PATH = " ";
    public static String PIC_PATH = " ";
    public static String ZOOM = " ";
    public static Location GPS_LOCATION;
    public static String TRIPID = "";
    public static String EMAIL = "";
    public static String DRIVER = "";
    public static String VEHICLE = "";
    public static String COMMENT = "";

    public static boolean PARCEL_VALIDATION;
    public static String PARCEL_INPUT = "";
    public static int PARCEL_POSITION;
    public static int tripCount = 0;

    public static ArrayList<Location> gpsList = new ArrayList<>();
    public static ArrayList<String> documentList = new ArrayList<>();
    public static ArrayList<String> validatedParcels = new ArrayList<>();
    public static ArrayList<String> uiValidatedParcels = new ArrayList<>();
    public static ArrayList<String> discrepancyParcels = new ArrayList<>();
    public static ArrayList<String> flaggedParcels = new ArrayList<>();
    public static ArrayList<String> tripList = new ArrayList<>();
    public static ArrayList<String> completedTrips = new ArrayList<>();
    public static ArrayList<String> downloadedTrips = new ArrayList<>();

    public static ArrayList<Integer> removedTripPosList = new ArrayList<>();

    public static String SAVED_DOCUMENT;

}
